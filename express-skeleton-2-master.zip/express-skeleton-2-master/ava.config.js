module.exports = {
  files: [
    "tests/**/*",
    "!tests/_utils",
    "!tests/_fixtures",
  ],
  environmentVariables: {
    NODE_NO_WARNINGS: "1"
  }
}
